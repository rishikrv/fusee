import {combineReducers} from 'redux';
import widgets from './widgets.reducer';

const reducer = combineReducers({
    widgets
});

export default reducer;
